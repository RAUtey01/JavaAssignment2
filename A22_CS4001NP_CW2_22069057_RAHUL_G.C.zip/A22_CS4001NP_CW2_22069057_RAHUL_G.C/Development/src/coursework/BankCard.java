package coursework;
/**
 * This class(bankCard) is the parent class of debitCard and creditCard.
 * @author (Rahul G.C.)
 * @version (a version number or a date)
 */
public class BankCard
{
    private int cardId ;//declaring cardId
    private double balanceAmount; // declaring balanceAmount
    private String bankAccount;// declaring bankAccount
    private String issuerBank;// declaring issuerBank
    private String clientName;// declaring clientName

    //This is no argument constructor
    public BankCard()
    {

    }

    //This is a parameterized constructor that accepts 4 parameters.
    public BankCard(int cardId, double balanceAmount, String issuerBank, String bankAccount)
    {
        this.cardId = cardId; //intializing cardId 
        this.balanceAmount = balanceAmount; // intializing balanceAmount
        this.bankAccount = bankAccount;// intializing bankAccount
        this.issuerBank = issuerBank;// intializing issuerBank
        this.clientName="";// intializing clientName
    }

    public BankCard(int cardId, double balanceAmount, String issuerBank, String bankAccount, String clientName) {
    }

    //getter method for cardId 
    public int getCardId()
    {
        return cardId;
    }
    // getter method for BalanceAmount
    public double getBalanceAmount()
    {
        return balanceAmount;
    }
    // getter method for BankAccount
    public String getBankAccount()
    {
        return bankAccount;
    }
    // getter method for IssuerBank
    public String getIssuerBank()
    {
        return issuerBank;
    }
    // getter method for ClientName
    public String getClientName()
    {
        return clientName;
    }
    // setter method for client name
    protected void setClientName(String newClientName)
    {
        this.clientName = newClientName;
    }
    // setter method for BalanceAmount
    protected void setBalance(double newBalanceAmount)
    {
        this.balanceAmount = newBalanceAmount;
    }
    //Method to display output for bank card
    protected void display()
    {
        if(clientName ==  "")
        {
            System.out.println("Client name not assigned! Please enter the name and Try Again.");
        }else{   
            System.out.println("The client name is " + clientName);
            System.out.println("The card ID is " + cardId); 
            System.out.println("The balanceAmount is " + balanceAmount);
            System.out.println("The issuer bank is " + issuerBank); 
            System.out.println("The bank account is " + bankAccount);
        }
    }



}
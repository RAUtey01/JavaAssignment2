import views.Front;

import javax.swing.*;

//This code declares a public class named "BankGUI" that inherits from the JFrame class.
public class BankGUI extends JFrame {
//    This code initializes a new object of the Front class .
//    assigns it to a variable called "front" within the main method.
    public static void main(String [] args){
        Front front = new Front();
        
    }
}

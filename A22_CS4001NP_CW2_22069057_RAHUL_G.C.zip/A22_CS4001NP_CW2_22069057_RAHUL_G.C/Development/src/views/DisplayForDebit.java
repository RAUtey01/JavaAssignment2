package views;

import coursework.BankCard;
import coursework.DebitCard;

import javax.swing.*;
import java.util.ArrayList;

//This code declares a public class named "DisplayForDebit" that inherits from the JFrame class.
public class DisplayForDebit extends JFrame {
    //Creating constructor for DisplayForDebit class
    //Arraylist parameter which contains list of BankCard object
    public DisplayForDebit(ArrayList<BankCard> bankCards){
        super(" Display Debit Cards");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(800, 800);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

        //Adding components
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        //ColumnNames array object created in order to hold names of the variables
        String[] columnNames = {"Card Id", "Bank Account", "Balance", "Client Name", " Issuer Bank", "Card Type", "Pin", "Has Withdrawn"};
        ArrayList<DebitCard> debitCards =new ArrayList<>();
        //iterating over 'bankCards' arraylist using enhanced loop syntax
        for (BankCard bankCard : bankCards) {
            //downcasting to access object of the BankCard class
            if (bankCard instanceof DebitCard) {
                debitCards.add((DebitCard) bankCard);
            }
        }
        // create data arrays for JTable to hold data which is to be displayed for debit
        String[][] data = new String[debitCards.size()][8];
        for (int i = 0; i < debitCards.size(); i++) {
            //provide each card data a place in data array
            data[i][0] = String.valueOf(bankCards.get(i).getCardId());
            data[i][1] = String.valueOf(bankCards.get(i).getBankAccount());
            data[i][2] = String.valueOf(bankCards.get(i).getBalanceAmount());
            data[i][3] = String.valueOf(bankCards.get(i).getClientName());
            data[i][4]= String.valueOf(bankCards.get(i).getIssuerBank());
            data[i][5] =  "Debit Card";
            data[i][6] = String.valueOf(debitCards.get(i).getPinNumber());
            data[i][7] = String.valueOf(debitCards.get(i).getHasWithdrawn());
        }
        JTable table = new JTable(data, columnNames);
        //Creating object for scroll functionality
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        //Adding panel
        add(panel);
    }
}
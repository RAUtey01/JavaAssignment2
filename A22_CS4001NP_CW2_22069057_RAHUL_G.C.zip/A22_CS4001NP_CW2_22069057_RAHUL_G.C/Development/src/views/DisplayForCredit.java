package views;

import coursework.BankCard;
import coursework.CreditCard;

import javax.swing.*;
import java.util.ArrayList;

//This code declares a public class named "DisplayForCredit" that inherits from the JFrame class.
public class DisplayForCredit extends JFrame {
    //Creating constructor for DisplayForCredit class
    //Arraylist parameter which contains list of BankCard object
    public DisplayForCredit(ArrayList<BankCard> bankCards){
        super(" Display Credit Cards");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(800, 800);
        setLocationRelativeTo(null);
        //RESIZEABLE
        setResizable(false);
        setVisible(true);
        //Adding components
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        //ColumnNames array object created in order to hold names of the columns which is to be displayed
        String[] columnNames = {"Card Id", "Bank Account", "Balance", "Client Name", "Card Type", "CVC Number", "Interest Rate","Expiration Date","isGranted","Credit Limit","Grace Period"};
        ArrayList<CreditCard> creditCards =new ArrayList<>();
        //iterating over 'bankCards' arraylist using enhanced loop syntax
        for (BankCard bankCard : bankCards) {
            //downcasting to access object of the BankCard class
            if (bankCard instanceof CreditCard) {
                creditCards.add((CreditCard) bankCard);
            }
        }
        // create data arrays for JTable to hold data which is to be displayed
        String[][] data = new String[creditCards.size()][11];
        //iterating through bankCards
        for (int i = 0; i < creditCards.size(); i++) {
            //provide each card data a place in data array
            data[i][0] = String.valueOf(creditCards.get(i).getCardId());
            data[i][1] = String.valueOf(creditCards.get(i).getBankAccount());
            data[i][2] = String.valueOf(creditCards.get(i).getBalanceAmount());
            data[i][3] = String.valueOf(creditCards.get(i).getClientName());
            data[i][4] = "Credit Card";
            data[i][5] = String.valueOf(creditCards.get(i).getCvcNumber());
            data[i][6] = String.valueOf(creditCards.get(i).getInterestRate());
            data[i][7] = String.valueOf(creditCards.get(i).getExpirationDate());
            data[i][8] = String.valueOf(creditCards.get(i).getIsGranted());
            data[i][9] = String.valueOf(creditCards.get(i).getCreditLimit());
            data[i][10] = String.valueOf(creditCards.get(i).getGracePeriod());
        }
        JTable table = new JTable(data, columnNames);
        //Creating object for scroll functionality
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        //Adding panel
        add(panel);
    }
}


package views;

import components.MyCustomButton;
import components.MyCustomHeading;

import coursework.BankCard;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
//This code declares a public class named "Front" that inherits from the JFrame class.
public class Front extends JFrame {
    //Arraylist parameter which contains list of BankCard object
    ArrayList<BankCard> bankCards = new ArrayList<>();


    //Adding custom components
    MyCustomHeading namasteEveryone, services;

    JRadioButton debitCard, creditCard, bankCard;

    MyCustomButton select;

    public Front(){
        //Calls superclass constructor
        super("Welcome");

        namasteEveryone = new MyCustomHeading("Welcome Everyone!");
        services = new MyCustomHeading("What features would you like to start up?");
        //initializing instance variables for RadioButton
        debitCard = new JRadioButton("Debit Card");
        creditCard = new JRadioButton("Credit Card");
        bankCard = new JRadioButton("Bank Card");
        ButtonGroup group= new ButtonGroup();
        group.add(debitCard);
        group.add(creditCard);
       group.add(bankCard);


        //initializing instance variables for button
        select = new MyCustomButton("Select");

        //Calls constructor of JFrame superclass and setting properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900,900);
        setLocationRelativeTo(null);
        setVisible(true);

        //GridBagLayout and GridBagConstraints for Front class
        GridBagLayout gblForFront = new GridBagLayout();
        GridBagConstraints gbcForFront = new GridBagConstraints();
        setLayout(gblForFront);

        //GridBagConstraints for namasteEveryone Heading
        gbcForFront.gridx = 0;
        gbcForFront.gridy = 0;
        gbcForFront.gridwidth = 2;
        gbcForFront.insets = new Insets(0, 500, 30, 0);
        namasteEveryone.setFont(new Font("Times New Romans", Font.BOLD, 45));
        add(namasteEveryone, gbcForFront);
        //GridBagConstraints for services Heading
        gbcForFront.gridx = 0;
        gbcForFront.gridy = 1;
        gbcForFront.insets = new Insets(0, 480, 50, 0);
        services.setFont(new Font("Times New Romans", Font.BOLD, 45));
        add(services, gbcForFront);

        //GridBagConstraints for bankCard button
        gbcForFront.gridx = 0;
        gbcForFront.gridy = 2;
        gbcForFront.insets = new Insets(0, 450, 30, 0);
        bankCard.setFont(new Font("sub Labeling",Font.BOLD, 25));
        add(bankCard, gbcForFront);

        //GridBagConstraints for debitCard button
        gbcForFront.gridx = 0;
        gbcForFront.gridy = 3;
        gbcForFront.insets = new Insets(0, 250, 30, 250);
        debitCard.setFont(new Font("sub Labeling",Font.BOLD, 25));
        add(debitCard, gbcForFront);

        //GridBagConstraints for credit card button
        gbcForFront.gridx = 1;
        gbcForFront.gridy = 3;
        gbcForFront.insets = new Insets(0, 850, 30, 0);
        creditCard.setFont(new Font("sub Labeling",Font.BOLD, 25));
        add(creditCard, gbcForFront);

        //GridBagConstraints for select button
        gbcForFront.gridx = 3;
        gbcForFront.gridy = 7;
        gbcForFront.insets = new Insets(0, 0, 30, 400);
        select.setFont(new Font("sub Labeling",Font.BOLD, 25));
        add(select, gbcForFront);




        //Creating actionListener for select button object
        select.addActionListener(e -> {
            if (bankCard.isSelected()){
                new Bank((bankCards));
            }
            if(debitCard.isSelected()){
                new Debit(bankCards);
            }
            if(creditCard.isSelected()){
                new Credit(bankCards);
            }

        });
    }

}
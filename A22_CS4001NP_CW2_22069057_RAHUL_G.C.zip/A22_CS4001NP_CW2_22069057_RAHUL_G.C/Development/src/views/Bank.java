package views;

import components.MyCustomTextField;
import components.MyCustomButton;
import components.MyCustomHeading;
import components.MyCustomLabel;
import coursework.BankCard;
import coursework.CreditCard;
import coursework.DebitCard;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

//This code declares a public class named "Bank" that inherits from the JFrame class.
public class Bank extends JFrame {

    // Custom Components for the Bank
    public MyCustomButton  addCreditButton, addDebitButton, backButton, clearButton ;

    public MyCustomHeading bankLabel, debitLabel, creditLabel ;

    public MyCustomLabel clientNameLabel, balanceAccountLabel, balanceAmountLabel, issuerBankLabel, cardIdLabel, pinNumberLabel, cvcNumberLabel,interestRateLabel, creditLimitLabel, gracePeriodLabel, expirationDateLabel ;


    public MyCustomTextField clientNameTf, cardIdTf, balanceAccountTf, balanceAmountTf, issuerBankTf, pinNumberTf, cvcNumberTf, interestRateTf, creditLimitTf, gracePeriodTf;

    public JComboBox currentDateDay, currentDateMonth, currentDateYear;

    //Constructor for Bank class
    //Arraylist parameter that contains list if BankCard objects to be displayed
    public Bank(ArrayList<BankCard> bankCards) {
        //Calls constructor of JFrame superclass and setting properties
        super("Bank");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900,900);
        setLocationRelativeTo(null);
        setVisible(true);

//initializing instance variables for Button
    addCreditButton = new MyCustomButton("Add Credit");
    addDebitButton = new MyCustomButton("Add Debit");
    backButton = new MyCustomButton("Back");
    clearButton = new MyCustomButton("Clear All");

//initializing instance variables for Headings
    bankLabel = new MyCustomHeading("Bank Card");
    debitLabel = new MyCustomHeading("Would you like to add Debit Card?");
    creditLabel = new MyCustomHeading("Would you like to add Credit Card?");

//initializing instance variables for Labels
    clientNameLabel = new MyCustomLabel("Client Name");
    cardIdLabel = new MyCustomLabel("Card ID");
    balanceAmountLabel = new MyCustomLabel("Balance Amount");
    balanceAccountLabel = new MyCustomLabel("Bank A/C");
    issuerBankLabel = new MyCustomLabel("Issuer Bank");
    pinNumberLabel = new MyCustomLabel("Pin Number");
    cvcNumberLabel = new MyCustomLabel("CVC Number");
    interestRateLabel = new MyCustomLabel( "Interest Rate");
    creditLimitLabel = new MyCustomLabel("Credit Limit");
    gracePeriodLabel = new MyCustomLabel("Grace Period");
    expirationDateLabel = new MyCustomLabel("Expiration Date");

//initializing instance variables for Textfields
    clientNameTf = new MyCustomTextField("");
    cardIdTf= new MyCustomTextField("");
    balanceAccountTf = new MyCustomTextField("");
    balanceAmountTf = new MyCustomTextField("");
    issuerBankTf = new MyCustomTextField("");
    pinNumberTf= new MyCustomTextField("");
    cvcNumberTf= new MyCustomTextField("");
    interestRateTf= new MyCustomTextField("");
    creditLimitTf= new MyCustomTextField("");
    gracePeriodTf= new MyCustomTextField("");

//initializing instance variables for ComboBox
        String years[] = {"Select Date","2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029","2030"};
        String months[] = {"Select Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        String days[] = {"Select Day", "01", "02", "03", "04", "05", "06", "07", "08","09", "10", "11" ,"13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26",
                "27" ,"28", "29", "30", "31", "32"};
        currentDateYear = new JComboBox<>(years);
        currentDateMonth = new JComboBox<>(months);
        currentDateDay = new JComboBox<>(days);

//GridBagLayout and GridBagConstraints for Bank
        GridBagLayout gblForBank = new GridBagLayout();
        GridBagConstraints gbcForBank = new GridBagConstraints();
        setLayout(gblForBank);
//GridBagConstraints for bankLabel
        gbcForBank.gridx=0;
        gbcForBank.gridy=0;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,150,50,150);
        add(bankLabel,gbcForBank);
        //GridBagConstraints for clientNameLabel
        gbcForBank.gridx=0;
        gbcForBank.gridy=1;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(clientNameLabel,gbcForBank);

//GridBagConstraints for ClientNameTextfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=1;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(clientNameTf,gbcForBank);

//GridBagConstraints for cardId Label
        gbcForBank.gridx=0;
        gbcForBank.gridy=2;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(cardIdLabel,gbcForBank);

//GridBagConstraints for cardId Textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=2;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(cardIdTf,gbcForBank);
//GridBagConstraints for balanceAmount label
        gbcForBank.gridx=0;
        gbcForBank.gridy=3;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(balanceAccountLabel,gbcForBank);

//GridBagConstraints for balanceAmount textfields
        gbcForBank.gridx=1;
        gbcForBank.gridy=3;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(balanceAccountTf,gbcForBank);

//GridBagConstraints for BalanceAmount label
        gbcForBank.gridx=0;
        gbcForBank.gridy=4;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,230);
        add(balanceAmountLabel,gbcForBank);

//GridBagConstraints for balanceAmount textfields
        gbcForBank.gridx=1;
        gbcForBank.gridy=4;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(balanceAmountTf,gbcForBank);

//GridBagConstraints for issuerbank label
        gbcForBank.gridx=0;
        gbcForBank.gridy=5;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(issuerBankLabel,gbcForBank);

//GridBagConstraints for issuerbank textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=5;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(issuerBankTf,gbcForBank);

//GridBagConstraints for debit label
        gbcForBank.gridx=1;
        gbcForBank.gridy=7;
        gbcForBank.gridwidth=2;
       gbcForBank.insets = new Insets(0,100,40,0);
        add(debitLabel,gbcForBank);

//GridBagConstraints for pinNumber label
        gbcForBank.gridx=0;
        gbcForBank.gridy=8;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(pinNumberLabel,gbcForBank);

//GridBagConstraints for pinNumer textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=8;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(pinNumberTf,gbcForBank);

//GridBagConstraints for addDebit button
        gbcForBank.gridx=1;
        gbcForBank.gridy=9;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,200,40,0);
        add(addDebitButton,gbcForBank);

//GridBagConstraints for creditlabel
        gbcForBank.gridx=1;
        gbcForBank.gridy=10;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,40,0);
        add(creditLabel,gbcForBank);

//GridBagConstraints for cvcNumber label
        gbcForBank.gridx=0;
        gbcForBank.gridy=11;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(cvcNumberLabel,gbcForBank);

//GridBagConstraints for cvcNumber textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=11;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(cvcNumberTf,gbcForBank);

//GridBagConstraints for interestRate label
        gbcForBank.gridx=0;
        gbcForBank.gridy=12;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(interestRateLabel,gbcForBank);

//GridBagConstraints for interestRate textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=12;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(interestRateTf,gbcForBank);

//GridBagConstraints for creditLimit label
        gbcForBank.gridx=0;
        gbcForBank.gridy=13;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(creditLimitLabel,gbcForBank);

//GridBagConstraints for creditLimit Textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=13;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(creditLimitTf,gbcForBank);

//GridBagConstraints for gracePeriod Label
        gbcForBank.gridx=0;
        gbcForBank.gridy=14;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(gracePeriodLabel,gbcForBank);

//GridBagConstraints for gracePeriod Textfield
        gbcForBank.gridx=1;
        gbcForBank.gridy=14;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,100,10,0);
        add(gracePeriodTf,gbcForBank);

//GridBagConstraints for expiration Date Label
        gbcForBank.gridx=0;
        gbcForBank.gridy=15;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,200);
        add(expirationDateLabel,gbcForBank);

//GridBagConstraints for currentDayYear
        gbcForBank.gridx = 1;
        gbcForBank.gridy = 15;
        gbcForBank.gridwidth = 2;
        gbcForBank.insets = new Insets(0, 10, 10, 0);
        add(currentDateYear,gbcForBank);

//GridBagConstraints for currentDateMonth
        gbcForBank.gridx = 1;
        gbcForBank.gridy = 15;
        gbcForBank.gridwidth = 2;
        gbcForBank.insets = new Insets(0, 230, 10, 0);
        add(currentDateMonth,gbcForBank);

//GridBagConstraints for currentDateDay
        gbcForBank.gridx = 2;
        gbcForBank.gridy = 15;
        gbcForBank.gridwidth = 2;
        gbcForBank.insets = new Insets(0, 0, 10, 100);
        add(currentDateDay,gbcForBank);

//GridBagConstraints for add Credit Button
        gbcForBank.gridx=0;
        gbcForBank.gridy=16;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,220,10,0);
        add(addCreditButton,gbcForBank);

//GridBagConstraints for back button
        gbcForBank.gridx=0;
        gbcForBank.gridy=17;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,250,10,0);
        add(backButton,gbcForBank);



//GridBagConstraints for clear button
        gbcForBank.gridx=0;
        gbcForBank.gridy=17;
        gbcForBank.gridwidth=2;
        gbcForBank.insets = new Insets(0,0,10,250);
        add(clearButton,gbcForBank);


        // checks various condition and calls the addDebit method to add the information
        addDebitButton.addActionListener(e -> {
            String balance = balanceAmountTf.getText();
            String card = cardIdTf.getText();
            String bankAccount = balanceAccountTf.getText();
            String issuerBank = issuerBankTf.getText();
            String clientName = clientNameTf.getText();
            String pin = pinNumberTf.getText();
            //if condition to check whether the arraylist is empty or not
            if (balance.equals("") || card.equals("") || bankAccount.equals("") || issuerBank.equals("") || clientName.equals("")) {
                JOptionPane.showMessageDialog( null, "Please fill the credentials for bank card");
            } else if
            (pin.equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill the value for pin number.");
            } else {
                try {
                    // changing the string values from text fields into required double, int values.
                    double balanceAmount = Double.parseDouble(balance);
                    int cardId = Integer.parseInt(card);
                    int pinNumber = Integer.parseInt(pin);
                    DebitCard debitCard = new DebitCard(cardId, balanceAmount, issuerBank, bankAccount, clientName, pinNumber);
                    bankCards.add(debitCard);
                    JOptionPane.showMessageDialog(null, "Debit Card added successfully");
                    clearForDebit();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,"Please enter the valid input for the fields");
                }
            }
        });



        //Creating actionListener for add Credit Button
        addCreditButton.addActionListener(e -> {
            String balance = balanceAmountTf.getText();
            String card = cardIdTf.getText();
            String bankAccount = balanceAccountTf.getText();
            String issuerBank = issuerBankTf.getText();
            String clientName = clientNameTf.getText();
            String cvcNum = cvcNumberTf.getText();
            String interestRt = interestRateTf.getText();
            String expirationDate = years[currentDateYear.getSelectedIndex()] + "-" + months[currentDateMonth.getSelectedIndex()] + "-" + days[currentDateDay.getSelectedIndex()];
            //if condition to check whether the arraylist is empty or not
            if (balance.equals("") || card.equals("") || bankAccount.equals("") || issuerBank.equals("") || clientName.equals("") ) {
                JOptionPane.showMessageDialog(null, "Please fill the credentials for bank card");
                //condition to check if the text fields are empty or not
            }else if
            (cvcNum.equals("") || interestRt.equals("") || currentDateYear.getSelectedIndex() == 0 || currentDateMonth.getSelectedIndex() == 0 || currentDateDay.getSelectedIndex() == 0){
                JOptionPane.showMessageDialog(null, "Please provide the inputs for credit.");
            }
            else {
                try {
                    // changing the string values from text fields into required double, int values.
                    double balanceAmount = Double.parseDouble(balance);
                    int cardId = Integer.parseInt(card);
                    int cvcNumber = Integer.parseInt(cvcNum);
                    int interestRate = Integer.parseInt(interestRt);

                    CreditCard creditCard = new CreditCard(cardId, balanceAmount, issuerBank, bankAccount, clientName, cvcNumber, interestRate, expirationDate);
                    bankCards.add(creditCard);
                    JOptionPane.showMessageDialog(null, "Credit Card added successfully");
                    clearForCredit();
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"Please enter the valid input for the fields");
                }
            }
        });

        //Creating actionListener for back Button
        backButton.addActionListener(e -> {
            dispose();
        });

        //Button to clear all the text fields
        clearButton.addActionListener(e -> {
            clear();
        });
    }
        //Method to clear all the text fields
    public void clear(){
        clientNameTf.setText("");
        cardIdTf.setText("");
        issuerBankTf.setText("");
        balanceAccountTf.setText("");
        balanceAmountTf.setText("");
        pinNumberTf.setText("");
        cvcNumberTf.setText("");
        interestRateTf.setText("");
        currentDateYear.setSelectedIndex(0);
        currentDateMonth.setSelectedIndex(0);
        currentDateDay.setSelectedIndex(0);
        gracePeriodTf.setText("");
        creditLimitTf.setText("");

    }
       //method to clear the pin number textfield
    public void clearForDebit(){
        pinNumberTf.setText("");
    }

        //method to clear all the textfields
    public void clearForCredit(){
        cvcNumberTf.setText("");
        interestRateTf.setText("");
        currentDateYear.setSelectedIndex(0);
        currentDateMonth.setSelectedIndex(0);
        currentDateDay.setSelectedIndex(0);
        gracePeriodTf.setText("");
        creditLimitTf.setText("");
    }

}



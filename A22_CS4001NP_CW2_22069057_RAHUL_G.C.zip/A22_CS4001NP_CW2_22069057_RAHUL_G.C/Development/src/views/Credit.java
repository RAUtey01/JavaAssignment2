package views;

import components.MyCustomButton;
import components.MyCustomHeading;
import components.MyCustomLabel;
import components.MyCustomTextField;
import coursework.BankCard;
import coursework.CreditCard;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

     //This code declares a public class named "Credit" that inherits from the JFrame class.
public class Credit extends JFrame {

    //Custom components like button,label,heading and textfields for Credit class
    public MyCustomButton setButton, cancelButton, backButton, clearForCreditButton, displayButton;


    public MyCustomHeading creditLabel, setCreditLimitLabel, cancelCreditCardLabel;


    public MyCustomLabel cardIdLabel, creditLimitLabel, gracePeriodLabel ;

    public MyCustomTextField cardIdTf, creditLimitTf, gracePeriodTf;

    //Creating constructor for Credit class
    //Arraylist parameter which contains list of BankCard object
    public Credit(ArrayList<BankCard> bankCards){
        super("Credit");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800,800);
        setLocationRelativeTo(null);
        setVisible(true);

        //initializing instance variables for Button
        setButton = new MyCustomButton("Set");
        cancelButton= new MyCustomButton("cancel Credit Card");
        backButton= new MyCustomButton("Back");
        clearForCreditButton= new MyCustomButton("Clear All");
        displayButton= new MyCustomButton( "Display");

        //initializing instance variables for Headings
        creditLabel = new MyCustomHeading("Credit Card");
        setCreditLimitLabel= new MyCustomHeading("Set your credit limit");
        cancelCreditCardLabel= new MyCustomHeading("Cancel credit card");

        //initializing instance variables for Label
        cardIdLabel = new MyCustomLabel("Card Id");
        creditLimitLabel= new MyCustomLabel("Credit Limit");
        gracePeriodLabel= new MyCustomLabel("Grace period");

        //initializing instance variables for Textfields
        cardIdTf= new MyCustomTextField("");
        creditLimitTf = new MyCustomTextField("");
        gracePeriodTf = new MyCustomTextField("");

        //GridBagLayout and GridBagConstraints for Credit class
        GridBagLayout gblForCredit = new GridBagLayout();
        GridBagConstraints gbcForCredit = new GridBagConstraints();
        setLayout(gblForCredit);

        //GridBagConstraints for credit Label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=0;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,150,50,150);
        add(creditLabel,gbcForCredit);
        //GridBagConstraints for cardId label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=1;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,0,50,200);
        add(cardIdLabel,gbcForCredit);

        //GridBagConstraints for cardId textfield
        gbcForCredit.gridx=1;
        gbcForCredit.gridy=1;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,100,50,0);
        add(cardIdTf,gbcForCredit);

        //GridBagConstraints for setCreditlimit label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=2;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,150,50,150);
        add(setCreditLimitLabel,gbcForCredit);
        //GridBagConstraints for credit limit label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=3;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,0,10,200);
        add(creditLimitLabel,gbcForCredit);

        //GridBagConstraints for credit limit textfield
        gbcForCredit.gridx=1;
        gbcForCredit.gridy=3;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,100,10,0);
        add(creditLimitTf,gbcForCredit);

        //GridBagConstraints for grace period label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=4;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,0,10,200);
        add(gracePeriodLabel,gbcForCredit);

        //GridBagConstraints for grace period textfield
        gbcForCredit.gridx=1;
        gbcForCredit.gridy=4;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,100,10,0);
        add(gracePeriodTf,gbcForCredit);

        //GridBagConstraints for set button
        gbcForCredit.gridx = 0;
        gbcForCredit.gridy = 5;
        gbcForCredit.gridwidth = 2;
        gbcForCredit.insets = new Insets(40, 200, 40, 200);
        add(setButton, gbcForCredit);
        //GridBagConstraints for cancel credit Label
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=6;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,150,50,150);
        add(cancelCreditCardLabel,gbcForCredit);

        //GridBagConstraints for cancel button
        gbcForCredit.gridx = 0;
        gbcForCredit.gridy = 7;
        gbcForCredit.gridwidth = 2;
        gbcForCredit.insets = new Insets(40, 200, 40, 200);
        add(cancelButton, gbcForCredit);
        //GridBagConstraints for back button
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=8;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,250,10,0);
        add(backButton,gbcForCredit);
        //GridBagConstraints for display button
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=8;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,0,10,30);
        add(displayButton,gbcForCredit);
        //GridBagConstraints for clear for credit button
        gbcForCredit.gridx=0;
        gbcForCredit.gridy=8;
        gbcForCredit.gridwidth=2;
        gbcForCredit.insets = new Insets(0,0,10,300);
        add(clearForCreditButton,gbcForCredit);

        //this is a button that takes in required inputs from the text fields and
        //checks various condition and calls the set method to set the amount
        setButton.addActionListener(e -> {
          try{
              //assigning input variable from textfield to new variable
            String cardIdForCredit = cardIdTf.getText();
            String creditLimitForCredit = creditLimitTf.getText();
            String gracePeriodForCredit = gracePeriodTf.getText();
              //if condition to check whether the arraylist is empty or not
            if(bankCards.isEmpty()){
                JOptionPane.showMessageDialog(null,"Please add credit card in Bank A/C first");
            } else if
                //condition to check if the text fields are empty or not
            (cardIdForCredit.isEmpty() || creditLimitForCredit.isEmpty() || gracePeriodForCredit.isEmpty() ){
                JOptionPane.showMessageDialog(null,"Please fill up the fields");
            }else{
            // changing the string values from text fields into required double, int values.
                    int cardId = Integer.parseInt(cardIdForCredit);
                    double newCreditLimit = Double.parseDouble(creditLimitForCredit);
                    int newGracePeriod = Integer.parseInt(gracePeriodForCredit);
                    boolean searchCard = false;
                    CreditCard creditCard = null;
                    //find the credit card object with the given card id
                    //It iterates over the "bankCards" ArrayList using the enhanced for loop syntax and checks each credit card object to find the one with the given card ID.
                for (BankCard bankCard1 : bankCards) {
                    //usage of downcasting to access the object of bankcard
                    if (bankCard1 instanceof CreditCard) {
                        creditCard = (CreditCard) bankCard1;
                        // checking if the card id of credit id matches with the card id of arraylist
                        if (creditCard.getCardId() == cardId) {
                            searchCard = true;
                            break;
                        }
                    }
                }
                if (searchCard) {
                    //calling the method set credit limit to set the credit limit.
                    setCreditLimit(creditCard,newCreditLimit,newGracePeriod);
                    // update the bankCards array with the newly updated credit card object
                    bankCards.set(bankCards.indexOf(creditCard), creditCard);
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill the correct Card Id");
                }
            }
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"Please fill the correct value for the fields");
                }
        });
        // Creating actionListener function For the cancel button
        cancelButton.addActionListener(e ->  {
        try {
            String cardIdForCreditCancel = cardIdTf.getText();

            //checks if the arraylist is empty
            if (bankCards.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please add credit card in Bank A/C first");
            } else if (cardIdForCreditCancel.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill up the fields");
            } else {
                int cardID = Integer.parseInt(cardIdForCreditCancel);
                boolean searchCard = false;
                CreditCard creditCard = null;
                //It iterates over the "bankCards" ArrayList using the enhanced for loop syntax and checks each credit card object to find the one with the given card ID.
                for (BankCard bankCard2 : bankCards) {
                    //usage of downcasting to access the object of bankcard
                    if (bankCard2 instanceof CreditCard) {
                        creditCard = (CreditCard) bankCard2;
                        if (creditCard.getCardId() == cardID) {
                            searchCard = true;
                            break;
                        }
                    }
                }
                if(searchCard){
                    //call the cancelcreditcard method from creditcard
                    cancelCreditCard(creditCard);
                    //updates the bankcard array with newly updated credit card object
                    bankCards.set(bankCards.indexOf(creditCard), creditCard);
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter the valid Card Id");
                }
            }
        }catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter the valid input");
        }
    });




        // Creating actionListener function For the display button
        displayButton.addActionListener(e -> {
            new DisplayForCredit(bankCards);
        });
        // Creating actionListener function For the back button
        backButton.addActionListener(e -> {
            dispose();
        });
        // Creating actionListener function For the clear button
        clearForCreditButton.addActionListener(e -> {
            clear();
        });

    }

    // method to clear the textfields
    public void clear() {
        cardIdTf.setText("");
        gracePeriodTf.setText("");
        creditLimitTf.setText("");
    }


    //a method to set the credit limit of credit card
    public void setCreditLimit(CreditCard creditCard,double newCreditLimit, int newGracePeriod){
        if (newCreditLimit >= 2.5 * creditCard.getBalanceAmount()){
            JOptionPane.showMessageDialog(null, "Your credit limit cannot be more than 2.3 times the balance amount.");
        }else {
            creditCard.setCreditLimit(newCreditLimit,newGracePeriod);//calling the setCreditLimit method from credit card.
            JOptionPane.showMessageDialog(null, "Your credit limit has been set.");
            clear();
        }
    }

    //a method to cancel the credit card
    public void cancelCreditCard(CreditCard creditCard){
        creditCard.cancelCreditCard();//calling the cancelcreditcard method from credit card
        JOptionPane.showMessageDialog(null, "Your credit card has been cancelled");
        clear();
    }
}




























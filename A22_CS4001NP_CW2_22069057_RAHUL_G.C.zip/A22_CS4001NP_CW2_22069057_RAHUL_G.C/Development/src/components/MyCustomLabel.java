package components;

import javax.swing.*;
import java.awt.*;
//Defines the CustomLabel which extends JLabel class
public class MyCustomLabel extends JLabel {
    //Constructor
    public MyCustomLabel (String text){
        super(text);// calls superclass constructor in order to initialize the label
        setFont(new Font("Arial",Font.PLAIN,15));
    }
}

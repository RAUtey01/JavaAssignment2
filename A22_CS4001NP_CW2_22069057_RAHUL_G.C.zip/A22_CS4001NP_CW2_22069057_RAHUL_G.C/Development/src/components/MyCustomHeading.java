package components;

import javax.swing.*;
import java.awt.*;

//Defines the CustomHeading which extends JLabel class
public class MyCustomHeading extends JLabel {
    //Constructor
    public MyCustomHeading(String text){
        super(text);// calls superclass constructor in order to initialize the label
        setFont(new Font("Arial",Font.BOLD,20));
    }


}

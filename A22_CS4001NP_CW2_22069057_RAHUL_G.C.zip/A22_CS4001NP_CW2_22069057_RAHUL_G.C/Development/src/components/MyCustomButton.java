package components;

import javax.swing.*;
import java.awt.*;

//Defines the CustomButton which extends JButton class
public class MyCustomButton extends JButton {
    //Constructor
    public MyCustomButton(String text){
        super(text);// calls superclass constructor in order to initialize the button
        setFont(new Font("Arial",Font.PLAIN,15));
    }
}

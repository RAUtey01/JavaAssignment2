package components;

import javax.swing.*;
//Defines the CustomTextField which extends JTextField class
public class MyCustomTextField extends JTextField {
//Constructor
    public MyCustomTextField(String text){
        super(text);// calls superclass constructor in order to initialize the textfield
        setColumns(20);

    }
}
